#!/usr/bin/env python3
import os
import subprocess
import sys

RED = "\033[91m"
RESET = "\033[0m"

logo = f"""
{RED}
 _       __     __        __
| |     / /__  / /____   / /_____  _____
| | /| / / _ \/ __/ _ \ / __/ __ \/ ___/
| |/ |/ /  __/ /_/  __// /_/ /_/ / /
|__/|__/\___/\__/\___(_)__/\____/_/

           LVEUNIX Ultimate Attack Toolkit
{RESET}
"""

menu = f"""
{RED}Choose your attack test:{RESET}
1) Web App Penetration Testing
2) Network Vulnerability Scanning
3) Subdomain & DNS Reconnaissance
4) Social Engineering Attacks
5) Password Cracking & Brute Force
6) Wireless Network Hacking
7) Exploit with Metasploit
8) Phishing Campaign Setup
9) Privilege Escalation Checks
10) Malware & Backdoor Deployment
11) Information Gathering & OSINT
12) Denial of Service Testing
0) Exit
"""

def run_cmd(cmd):
    print(f"{RED}Running:{RESET} {cmd}")
    subprocess.call(cmd, shell=True)

def install_tools():
    print(f"{RED}Installing required tools...{RESET}")
    tools = [
        "nmap", "sqlmap", "nikto", "owasp-zap", "hydra", "john",
        "aircrack-ng", "reaver", "wifite", "metasploit-framework",
        "gophish", "theharvester", "sublist3r", "amass",
        "dnsenum", "set", "medusa", "maltego",
        "loic", "wget"  # wget for downloads if needed
    ]
    run_cmd(f"sudo apt update && sudo apt install -y {' '.join(tools)}")

def web_app_test():
    print(f"{RED}Starting Web Application Penetration Testing...{RESET}")
    target = input("Enter target URL or IP: ")
    run_cmd(f"sqlmap -u {target} --batch")
    run_cmd(f"nikto -h {target}")

def network_scan():
    print(f"{RED}Starting Network Vulnerability Scanning...{RESET}")
    target = input("Enter target IP or network (e.g., 192.168.1.0/24): ")
    run_cmd(f"nmap -A {target}")

def dns_recon():
    print(f"{RED}Starting Subdomain & DNS Reconnaissance...{RESET}")
    domain = input("Enter domain: ")
    run_cmd(f"sublist3r -d {domain}")
    run_cmd(f"amass enum -d {domain}")

def social_eng():
    print(f"{RED}Starting Social Engineering Toolkit...{RESET}")
    run_cmd("set")

def password_crack():
    print(f"{RED}Starting Password Cracking & Brute Force...{RESET}")
    target = input("Enter target IP/host: ")
    service = input("Enter service (ssh, ftp, http): ")
    wordlist = input("Enter wordlist path: ")
    run_cmd(f"hydra -L {wordlist} -P {wordlist} {target} {service}")

def wireless_hack():
    print(f"{RED}Starting Wireless Network Hacking...{RESET}")
    run_cmd("wifite")

def metasploit_exploit():
    print(f"{RED}Launching Metasploit Framework...{RESET}")
    run_cmd("msfconsole")

def phishing_setup():
    print(f"{RED}Launching Gophish Phishing Toolkit...{RESET}")
    run_cmd("gophish")

def priv_escalation():
    print(f"{RED}Checking Privilege Escalation Vectors...{RESET}")
    print("Use Linux Exploit Suggester or Windows tools (manual).")

def malware_deploy():
    print(f"{RED}Malware & Backdoor Deployment (manual steps)...{RESET}")
    print("Please deploy your RAT or backdoor manually.")

def info_gathering():
    print(f"{RED}Starting OSINT & Information Gathering...{RESET}")
    target = input("Enter domain or email: ")
    run_cmd(f"theharvester -d {target} -b all")

def dos_attack():
    print(f"{RED}Starting Denial of Service Testing...{RESET}")
    target = input("Enter target IP or URL: ")
    print("Use your preferred DoS tool manually.")

def main():
    print(logo)
    while True:
        print(menu)
        choice = input("Select option (0-12): ").strip()
        if choice == "1":
            web_app_test()
        elif choice == "2":
            network_scan()
        elif choice == "3":
            dns_recon()
        elif choice == "4":
            social_eng()
        elif choice == "5":
            password_crack()
        elif choice == "6":
            wireless_hack()
        elif choice == "7":
            metasploit_exploit()
        elif choice == "8":
            phishing_setup()
        elif choice == "9":
            priv_escalation()
        elif choice == "10":
            malware_deploy()
        elif choice == "11":
            info_gathering()
        elif choice == "12":
            dos_attack()
        elif choice == "0":
            print("Exiting...")
            sys.exit(0)
        else:
            print("Invalid option, try again.")

if __name__ == "__main__":
    main()