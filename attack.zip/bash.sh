#!/bin/bash
echo "Updating packages and installing required tools for LVEUNIX Attack Toolkit..."

sudo apt update

# تثبيت الأدوات الأساسية
sudo apt install -y nmap sqlmap nikto owasp-zap hydra john aircrack-ng reaver wifite metasploit-framework gophish theharvester sublist3r amass dnsenum set medusa maltego loic wget

echo "All tools installed. You can now run the tool by executing: python3 lveunix_attack_tool.py"