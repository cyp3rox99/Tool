#!/bin/bash

# مسار سكربت بايثون الأداة
SCRIPT_PATH="./lveosint.py"  # عدل هنا لو اسم الملف مختلف أو مكانه غير هذا

# تأكد إن السكربت موجود
if [ ! -f "$SCRIPT_PATH" ]; then
  echo "ERROR: سكربت البايثون $SCRIPT_PATH غير موجود"
  exit 1
fi

# نسخ السكربت إلى /usr/local/bin/osint
sudo cp "$SCRIPT_PATH" /usr/local/bin/osint

# تعيين صلاحيات التنفيذ
sudo chmod +x /usr/local/bin/osint

# تأكد إن osint يعمل
echo "تم تثبيت الأداة! جرب الأمر:"
echo "  osint"

exit 0