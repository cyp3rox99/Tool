#!/usr/bin/env python3
import os
import subprocess
import shutil
import sys
import pyfiglet

# === Banner ===
def print_banner():
    banner = pyfiglet.figlet_format("LVEOSINT")
    print(banner)
    print("by lveuia & 2zs\n")

# === Check if tool exists ===
def check_tool(tool):
    return shutil.which(tool) is not None

# === Install tool using apt ===
def install_tool(tool):
    print(f"[+] Installing {tool} ...")
    subprocess.run(['sudo', 'apt', 'install', '-y', tool], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# === Run shell commands and print output ===
def run_command(cmd_list):
    try:
        result = subprocess.run(cmd_list, capture_output=True, text=True, check=True)
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"[-] Error running command: {' '.join(cmd_list)}")
        print(e)

# === Tools and their commands ===
TOOLS = {
    "whois": ["whois"],
    "dig": ["dig"],
    "nmap": ["nmap", "-sV"],
    "theHarvester": ["theharvester", "-d"],  # requires domain argument
    "sublist3r": ["sublist3r", "-d"],       # requires domain argument
    "shodan": ["shodan", "search"],         # requires query argument, needs shodan CLI & API key
    "recon-ng": ["recon-ng", "-m", "recon/domains-hosts/google_site"], # example module
    "crtsh": ["curl", "https://crt.sh/?q="], # for querying crt.sh (append domain)
    # Add more tools here...
}

# === Install missing tools automatically ===
def ensure_tools(tools):
    for t in tools:
        if not check_tool(t):
            install_tool(t)

# === Run selected scan ===
def run_osint_tool(tool_name, target=None):
    if tool_name not in TOOLS:
        print(f"[-] Tool {tool_name} not supported yet.")
        return

    if not check_tool(tool_name):
        install_tool(tool_name)

    cmd = TOOLS[tool_name].copy()

    # Handle tools that need arguments
    if tool_name in ["theHarvester", "sublist3r"]:
        if not target:
            print(f"[-] {tool_name} needs a target domain!")
            return
        cmd.append(target)

    elif tool_name == "shodan":
        if not target:
            print("[-] Shodan needs a search query!")
            return
        cmd.append(target)

    elif tool_name == "crtsh":
        if not target:
            print("[-] crt.sh needs a domain!")
            return
        cmd[-1] += target

    elif tool_name == "recon-ng":
        print("[*] Recon-ng is a complex framework, please use it interactively.")
        subprocess.run(["recon-ng"])
        return

    else:
        # For tools like nmap, whois, dig which need target arg
        if target:
            cmd.append(target)

    print(f"[*] Running {' '.join(cmd)}\n")
    run_command(cmd)

# === Main menu ===
def main():
    print_banner()

    tools_list = list(TOOLS.keys())
    while True:
        print("Select OSINT tool to run:")
        for idx, tool in enumerate(tools_list, 1):
            print(f"{idx}) {tool}")
        print("0) Exit")

        choice = input("Choose an option: ").strip()
        if choice == "0":
            print("Goodbye!")
            break
        if not choice.isdigit() or int(choice) not in range(1, len(tools_list)+1):
            print("Invalid choice!")
            continue

        tool = tools_list[int(choice)-1]
        target = None
        if tool in ["theHarvester", "sublist3r", "shodan", "crtsh", "nmap", "whois", "dig"]:
            target = input("Enter target domain or IP: ").strip()
            if not target:
                print("Target is required!")
                continue

        run_osint_tool(tool, target)

if __name__ == "__main__":
    try:
        import pyfiglet
    except ImportError:
        print("[*] Installing pyfiglet for banner...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pyfiglet"])
    main()